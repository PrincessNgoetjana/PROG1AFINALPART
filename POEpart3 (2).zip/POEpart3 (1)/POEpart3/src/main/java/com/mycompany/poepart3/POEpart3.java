/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poepart3;

/**
 *
 * @author packardbell
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class POEpart3 {

/*import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;*/

class Task {
    String developer;
    String taskName;
    int taskID;
    int taskDuration;
    String taskStatus;

    public Task(String developer, String taskName, int taskID, int taskDuration, String taskStatus) {
        this.developer = developer;
        this.taskName = taskName;
        this.taskID = taskID;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
    }
}

public class TaskManager {
    private List<String> developers;
    private List<String> taskNames;
    private List<Integer> taskIDs;
    private List<Integer> taskDurations;
    private List<String> taskStatuses;
    private List<Task> tasks;

    public TaskManager() {
        developers = new ArrayList<>();
        taskNames = new ArrayList<>();
        taskIDs = new ArrayList<>();
        taskDurations = new ArrayList<>();
        taskStatuses = new ArrayList<>();
        tasks = new ArrayList<>();
    }

    public void addTask(String developer, String taskName, int taskID, int taskDuration, String taskStatus) {
        developers.add(developer);
        taskNames.add(taskName);
        taskIDs.add(taskID);
        taskDurations.add(taskDuration);
        taskStatuses.add(taskStatus);
        tasks.add(new Task(developer, taskName, taskID, taskDuration, taskStatus));
    }

    public void displayTasksWithStatus(String status) {
        for (int i = 0; i < taskStatuses.size(); i++) {
            if (taskStatuses.get(i).equalsIgnoreCase(status)) {
                System.out.println("Developer: " + developers.get(i));
                System.out.println("Task Name: " + taskNames.get(i));
                System.out.println("Task Duration: " + taskDurations.get(i));
                System.out.println("Task Status: " + taskStatuses.get(i));
                System.out.println();
            }
        }
    }

    public void displayLongestTask() {
        int maxDuration = Integer.MIN_VALUE;
        int maxIndex = -1;

        for (int i = 0; i < taskDurations.size(); i++) {
            if (taskDurations.get(i) > maxDuration) {
                maxDuration = taskDurations.get(i);
                maxIndex = i;
            }
        }

        if (maxIndex != -1) {
            System.out.println("Developer: " + developers.get(maxIndex));
            System.out.println("Task Duration: " + taskDurations.get(maxIndex));
        }
    }

    public void searchTaskByName(String name) {
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(name)) {
                System.out.println("Task Name: " + taskNames.get(i));
                System.out.println("Developer: " + developers.get(i));
                System.out.println("Task Status: " + taskStatuses.get(i));
                System.out.println();
                return;  // assuming task names are unique
            }
        }

        System.out.println("Task not found.");
    }

    public void searchTasksByDeveloper(String developer) {
        for (int i = 0; i < developers.size(); i++) {
            if (developers.get(i).equalsIgnoreCase(developer)) {
                System.out.println("Task Name: " + taskNames.get(i));
                System.out.println("Task Status: " + taskStatuses.get(i));
                System.out.println();
            }
        }
    }

    public void deleteTask(String taskName) {
        int index = -1;

        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                index = i;
                break;  // assuming task names are unique
            }
        }

        if (index != -1) {
            developers.remove(index);
            taskNames.remove(index);
            taskIDs.remove(index);
            taskDurations.remove(index);
            taskStatuses.remove(index);
            tasks.remove(index);
            System.out.println("Task deleted.");
        } else {
            System.out.println("Task not found.");
        }
    }

    public void displayTaskReport() {
        for (Task task : tasks) {
            System.out.println("Developer: " + task.developer);
            System.out.println("Task Name: " + task.taskName);
            System.out.println("Task ID: " + task.taskID);
            System.out.println("Task Duration: " + task.taskDuration);
            System.out.println("Task Status: " + task.taskStatus);
            System.out.println();
        }
    }

    public static void main(String[] args) {
        TaskManager taskManager = new TaskManager();

        // Populate the arrays with test data
        taskManager.addTask("Mike Smith", "Create Login", 1, 5, "To Do");
        taskManager.addTask("Edward Harrison", "Create Add Features", 2, 8, "Doing");
        taskManager.addTask("Samantha Paulson", "Create Reports", 3, 2, "Done");

        // Display tasks with status "Done"
        taskManager.displayTasksWithStatus("Done");

        // Display the developer and duration of the task with the longest duration
        taskManager.displayLongestTask();

        // Search for a task by name
        taskManager.searchTaskByName("Create Reports");

        // Search for tasks assigned to a developer
        taskManager.searchTasksByDeveloper("Mike Smith");

        // Delete a task
        taskManager.deleteTask("Create Add Features");

        // Display the task report
        taskManager.displayTaskReport();
    }
}
}


